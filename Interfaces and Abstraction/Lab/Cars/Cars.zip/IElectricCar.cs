﻿namespace Cars
{
    public interface IElectricCar
    {
        int Battery { get; }
    }
}
