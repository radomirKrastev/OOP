﻿namespace RawData.CarParts
{
    public class Cargo
    {
        public int Weight;
        public string Type;

        public Cargo (int weight, string type)
        {
            this.Weight = weight;
            this.Type = type;
        }
    }
}
